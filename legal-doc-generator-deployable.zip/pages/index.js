export default function Home() {
  return (
    <div style={{ textAlign: 'center', padding: '4rem' }}>
      <h1>Redactador Legal Exprés</h1>
      <p>Tu documento legal en menos de 2 minutos</p>
    </div>
  );
}